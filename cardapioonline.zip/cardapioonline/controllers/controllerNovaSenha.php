<?php

require_once(__DIR__.'/../models/UsuarioDAO.php');
require_once(__DIR__.'/../models/Usuario.php');
require_once(__DIR__.'/../controllers/controllerRecuperarSenha.php');

class controllerNovaSenha{
    public function __construct() { }

    public function alteraSenha(){
        try{

            if(session_status() === PHP_SESSION_NONE){
                session_start();
            }

            if(isset($_POST['botao_alterar'])){
                $novasenha = htmlspecialchars($_POST['novasenha']);
                $confsenha = htmlspecialchars($_POST['confsenha']);
                
                $usuarioDAO = new UsuarioDAO();
                $email = $_SESSION['email'];
                $pegaDados = $usuarioDAO->pesquisaUsuarioEmail($email);

                if($novasenha === $confsenha){
                    if($pegaDados){
                        $nome = $pegaDados['nome'];
                        $email = $pegaDados['email'];
                        $cpf = $pegaDados['cpf'];
                        $telefone = $pegaDados['telefone'];
                        $idUsuario = $pegaDados['fk_id_usuario'];
    
                        $usuario = new Usuario($nome, $email, $cpf, $telefone, md5($novasenha));
                        $usuarioDAO = new UsuarioDAO();
        
                        $atualizaUsuario = $usuarioDAO->update($idUsuario, $usuario);
                        
                        if($atualizaUsuario){
                            $_SESSION['mensagem'] = "Senha Alterada com Sucesso!";
                        }else{
                            $_SESSION['mensagem'] = "ERRO! Tente Novamente mais tarde!";
                        }
                        header('Location: /cardapioonline/index.php'); 
                        exit;                       
                    }
                }else{
                    $_SESSION['mensagem'] = "ERRO! As Senhas não são iguais!";
                    header('Location: ' . $_SERVER['HTTP_REFERER']);
                    exit;
                }
            }    
        }
        catch (Exception $excecao) {
			throw $excecao;
		}
    }
}

if (isset($_POST['botao_alterar'])===true){
	//sanitiza a string de operação obtida por meio do post
	$operacao=htmlspecialchars($_POST['botao_alterar']);
	
	$controllerNovaSenha = new controllerNovaSenha();
			
	switch ($operacao) {		
		case 'alterar':
			$controllerNovaSenha->alteraSenha();
			break;
	}
}
    
    
