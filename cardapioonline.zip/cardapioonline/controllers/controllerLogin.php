<?php

require_once(__DIR__.'/../models/usuarioDAO.php');

class ControllerLogin{

    public function __construct() { }

    public function pesquisarUsuario(){
        try{
            if(session_status() === PHP_SESSION_NONE){
                session_start();
            }

            if(isset($_POST['botao_login'])){
                $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL); 
                $senha = filter_input(INPUT_POST, 'senha', FILTER_SANITIZE_STRING);

                $usuarioDAO = new UsuarioDAO();
                $pesquisaUsuario = $usuarioDAO->find($email);

                if($pesquisaUsuario){
                    if(md5($senha) === $pesquisaUsuario->getSenha()){
                        $_SESSION['idUsuario'] = $pesquisaUsuario->getIdUsuario();
                        $_SESSION['nome'] = $pesquisaUsuario->getNome();
                        $_SESSION['email'] = $pesquisaUsuario->getEmail();
                        $_SESSION['cpf'] = $pesquisaUsuario->getCpf();
                        $_SESSION['telefone'] = $pesquisaUsuario->getTelefone();

                        header('Location: '.  dirname($_SERVER['HTTP_REFERER']) . '/home_cliente.php');

                    } else{
                        echo "Senha Incorreta!";
                    }
                } else{
                    echo "Usuário não encontrado!";
                }



            }
        }catch(Exception $excecao){
            throw $excecao;
        }

    }
}

?>