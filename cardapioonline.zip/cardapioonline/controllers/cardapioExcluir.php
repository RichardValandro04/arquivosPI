<?php 

// Classe de acesso ao banco de dados
// __DIR__ -> O diretório físico do arquivo
require_once(__DIR__.'/../models/docesDAO.php');
require_once(__DIR__.'/../models/recheioBoloDAO.php');

class CardapioExcluir {
    public function deletarRegistro(){
        if(session_status() === PHP_SESSION_NONE){
            session_start();
        }
            $id = $_POST['id'];
            $tipo = $_POST['tipo'];


            if ($tipo === 'doce') {
                $docesDAO = new DocesDAO();
                $coluna = "pk_id_doce";
                $deletarDoce = $docesDAO-> delete($id, $coluna);
                if($deletarDoce){
                    $_SESSION['mensagem'] = "Doce Deletado com Sucesso";
                    header('Location: ' . $_SERVER['HTTP_REFERER']);
                    exit;
                }
                else{
                    $_SESSION['mensagem'] = "Erro! Tente Novamente";
                    header('Location: ' . $_SERVER['HTTP_REFERER']);
                    exit;                
                }
            } else if ($tipo === 'recheio') {
                $recheioBoloDAO = new RecheioBoloDAO();
                $coluna = "pk_id_recheio";
                $deletarRecheio = $recheioBoloDAO-> delete($id, $coluna);
                if($deletarRecheio){
                    $_SESSION['mensagem'] = "Recheio Deletado com Sucesso";
                    header('Location: ' . $_SERVER['HTTP_REFERER']);
                    exit;
                }
                else{
                    $_SESSION['mensagem'] = "Erro! Tente Novamente";
                    header('Location: ' . $_SERVER['HTTP_REFERER']);
                    exit;                
                }
            }
        }
    }

?>


