<?php

require_once(__DIR__.'/../models/usuarioDAO.php');
require_once(__DIR__.'/../models/enderecoDAO.php');


class ControllerCadastro{
    
    public function __construct() { }

    public function incluirUsuario(){
        try{

            if(session_status() === PHP_SESSION_NONE){
                session_start();
            }

            if(isset($_POST['botao_registro'])){

                $nome = filter_input(INPUT_POST, 'nome_completo', FILTER_SANITIZE_STRING); 
                // $nome = htmlspecialchars($_POST['nome'])
                $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL); 
                $cpf = filter_input(INPUT_POST, 'cpf', FILTER_SANITIZE_STRING); 
                $telefone = filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_STRING); 
                $senha = filter_input(INPUT_POST, 'senha', FILTER_SANITIZE_STRING);
                $conf_senha = filter_input(INPUT_POST, 'conf_senha', FILTER_SANITIZE_STRING);
                
                $cep = filter_input(INPUT_POST, 'cep', FILTER_SANITIZE_STRING); 
                $rua = filter_input(INPUT_POST, 'rua', FILTER_SANITIZE_STRING); 
                $bairro = filter_input(INPUT_POST, 'bairro', FILTER_SANITIZE_STRING); 
                $cidade = filter_input(INPUT_POST, 'cidade', FILTER_SANITIZE_STRING); 
                $uf = filter_input(INPUT_POST, 'uf', FILTER_SANITIZE_STRING); 
                $num = filter_input(INPUT_POST, 'numero', FILTER_SANITIZE_STRING); 
                $complemento = filter_input(INPUT_POST, 'complemento', FILTER_SANITIZE_STRING);


                $usuarioDAO = new UsuarioDAO();
                $enderecoDAO = new EnderecoDAO();

                $usuario = new Usuario($nome, $email, $cpf, $telefone, $senha);
                

                // Inserir usuário e verificar se foi inserido com sucesso
                $usuario_id = $usuarioDAO->insert($usuario);

                if ($usuario_id) {
                    // Se o usuário foi inserido com sucesso, agora inserimos o endereço
                    $endereco = new Endereco($usuario_id, $cep, $num, $complemento);

                    // Associar o endereço ao usuário pelo ID
                    if ($enderecoDAO->insertEnderecoUsuario($endereco)) {
                        $_SESSION['mensagem'] = "Cadastro Realizado com Sucesso";
                    } else {
                        $_SESSION['mensagem'] = "Erro ao cadastrar endereço!";
                    }
                } else {
                    $_SESSION['mensagem'] = "Erro ao cadastrar usuário!";
                }

            header('Location: '.  dirname($_SERVER['HTTP_REFERER']) . '/index.php');
            }

            
        }
        catch (Exception $excecao) {
			throw $excecao;
		}
    }
}

if (isset($_POST['botao_registro'])===true){

	//sanitiza a string de operação obtida por meio do post
	$operacao=htmlspecialchars($_POST['botao_registro']);
	
	
	$controllerCadastro = new controllerCadastro();
			
	switch ($operacao) {		
		case 'incluir':
			$controllerCadastro->incluirUsuario();
			break;
	}
}
?>