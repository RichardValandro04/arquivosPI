<?php 
require_once(__DIR__.'/../models/docesDAO.php');
require_once(__DIR__.'/../models/enderecoDAO.php');
require_once(__DIR__.'/../models/pedidoDAO.php');
require_once(__DIR__.'/../models/tamanhosBoloDAO.php');
require_once(__DIR__.'/../models/usuarioDAO.php');
require_once(__DIR__.'/../models/recheioBoloDAO.php');

if(session_status() === PHP_SESSION_NONE){
    session_start();
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Recebe o corpo da requisição (JSON)
    $json = file_get_contents('php://input');

    if (json_last_error() !== JSON_ERROR_NONE) {
        // Lidar com erro de JSON
        $_SESSION['mensagem'] = "Erro ao processar os dados!";
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    }

    // Decodifica o JSON em um array associativo
    $data = json_decode($json, true);
    $_SESSION['dados'] = $data;

    var_dump($data);
    
    }
?>


