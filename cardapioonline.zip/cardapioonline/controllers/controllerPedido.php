<?php 
require_once(__DIR__.'/../models/docesDAO.php');
require_once(__DIR__.'/../models/enderecoDAO.php');
require_once(__DIR__.'/../models/pedidoDAO.php');
require_once(__DIR__.'/../models/tamanhosBoloDAO.php');
require_once(__DIR__.'/../models/usuarioDAO.php');
require_once(__DIR__.'/../models/recheioBoloDAO.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Código para manipulação de requisição POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recebe o corpo da requisição (JSON)
    $json = file_get_contents('php://input');

    if (json_last_error() !== JSON_ERROR_NONE) {
        // Lidar com erro de JSON
        $_SESSION['mensagem'] = "Erro ao processar os dados!";
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    }

    // Decodifica o JSON em um array associativo
    $data = json_decode($json, true);
    $_SESSION['dados'] = $data;

    var_dump($data);
}

// Definição da classe
class ControllerPedido {
    // Outros métodos e propriedades da classe

    public function listarEnderecos($idUsuario) { 
        try {
            // Instancia a classe de acesso ao banco de dados
            $enderecoDAO = new EnderecoDAO();
            return $enderecoDAO->pesquisaEnderecoPorUsuario($idUsuario);
        }
        catch (Exception $excecao) {
            // Em caso de exceção, você pode logar o erro ou tratá-lo conforme necessário
            error_log($excecao->getMessage());
            return []; // Retorna um array vazio em caso de erro
        }
    }
}
?>
