<?php 

//Classe de acesso ao banco de dados
//__DIR__ -> O diretório físico do arquivo, por exemplo: D:\marta\IFES\ProgramacaoWeb\usbwebserver_v8.6\usbwebserver\root\codigoprogwebphp\mvc\controller
require_once(__DIR__.'/../models/usuarioDAO.php');


class ControllerClientes {
	

	public function __construct() { }
	
		/*Lista os clientes e seus respectivos enderecos*/
		public function listarUsuarios() {
			try {
				//instancia classes de banco
				$usuarioDAO = new usuarioDAO();
				return $usuarioDAO->findAll();
			}
			catch (Exception $excecao) {
				throw $excecao;
			}
		}


}

?>