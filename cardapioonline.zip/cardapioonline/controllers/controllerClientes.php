<?php 

//Classe de acesso ao banco de dados
//__DIR__ -> O diretório físico do arquivo, por exemplo: D:\marta\IFES\ProgramacaoWeb\usbwebserver_v8.6\usbwebserver\root\codigoprogwebphp\mvc\controller
require_once(__DIR__.'/../models/usuarioDAO.php');


class ControllerClientes {
	

	public function __construct() { }
	
		/*Lista os clientes e seus respectivos enderecos*/
		public function listarUsuarios() {
			try {
				//instancia classes de banco
				$usuarioDAO = new usuarioDAO();
				return $usuarioDAO->pesquisaUsuarios();
			}
			catch (Exception $excecao) {
				throw $excecao;
			}
		}

		public function alterarEmail(){
			try{

				if (session_status() === PHP_SESSION_NONE) {
					session_start();
				}
				
				if(isset($_POST['salvarEmail'])){
					$emailAntigo = htmlspecialchars($_SESSION['email']);
					$idUsuario = htmlspecialchars($_SESSION['idUsuario']);
	
					$email = htmlspecialchars($_POST['campo_email']);


					$usuarioDAO = new UsuarioDAO();
					$pesquisaUsuario = $usuarioDAO->pesquisaUsuarioEmail($email);
					
					if($pesquisaUsuario){
						$_SESSION['mensagem'] = "o Email ". $email . " já está em uso!";
						header('Location: ' . $_SERVER['HTTP_REFERER']);
						exit;   
					}
	
					if($usuarioDAO->alteraEmail($idUsuario, $email)){
						$_SESSION['mensagem'] = "Email Alterado com Sucesso! <br>Email Antigo: " . $emailAntigo . "<br>Email Novo: " . $email;
						$_SESSION['email'] = $email;
						header('Location: ' . $_SERVER['HTTP_REFERER']);
						exit;
					}
					   
	
				}
	
				
			}
			catch (Exception $excecao) {
				throw $excecao;
			}
		}


}


if (isset($_POST['salvarEmail']) === true){
	//sanitiza a string de operação obtida por meio do post
	$operacao = htmlspecialchars($_POST['salvarEmail']);
	
	$controllerClientes = new ControllerClientes();
			
	switch ($operacao) {		
		case 'salvarEmail':
			$controllerClientes->alterarEmail();
			break;
	}
}

?>