<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        

        $nome = filter_input(INPUT_POST, 'nome_completo', FILTER_SANITIZE_STRING); 
        // $nome = htmlspecialchars($_POST['nome'])
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL); 
        $cpf = filter_input(INPUT_POST, 'cpf', FILTER_SANITIZE_STRING); 
        $telefone = filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_STRING); 
        $senha = filter_input(INPUT_POST, 'senha', FILTER_SANITIZE_STRING);
        $conf_senha = filter_input(INPUT_POST, 'conf_senha', FILTER_SANITIZE_STRING);
        
        $cep = filter_input(INPUT_POST, 'cep', FILTER_SANITIZE_STRING); 
        $rua = filter_input(INPUT_POST, 'rua', FILTER_SANITIZE_STRING); 
        $bairro = filter_input(INPUT_POST, 'bairro', FILTER_SANITIZE_STRING); 
        $cidade = filter_input(INPUT_POST, 'cidade', FILTER_SANITIZE_STRING); 
        $uf = filter_input(INPUT_POST, 'uf', FILTER_SANITIZE_STRING); 
        $num = filter_input(INPUT_POST, 'numero', FILTER_SANITIZE_STRING); 
        $complemento = filter_input(INPUT_POST, 'complemento', FILTER_SANITIZE_STRING);


        var_dump( "nome: ", $nome, 
        "email: ",$email, 
        "cpf: ",$cpf, 
        "telefone: ",$telefone, 
        "senha: ",$senha, 
        "conf_senha: ",$conf_senha, 
        "cep: ",$cep, 
        "rua: ",$rua, 
        "bairro: ",$bairro, 
        "cidade: ",$cidade, 
        "uf: ",$uf, 
        "num: ",$num,
        "complemento: ",$complemento);
    }
?>