
    <?php
    $csscustomiza = "recuperar_senha.css";
    include 'header_2.php';

    ?>


    <!--nav que inclui uma tag "p", uma div "email" e um botão "enviar"-->
    <form class="container">
        <p class="texto_central">Confirme o email cadastrado para que <span>possamos enviar o link de alteração de senha</p>

        <!--div que inclui dois campos, um label "email" e um input-->
        <div class="email">
            <label for="email">E-Mail</label>
            <input type="text" id="email" name="email">
        </div>

        <!--botão de confirmação de email para envio do link de alteração de senha-->
        <button type="submit" class="botao_enviar">ENVIAR</button>
    </form>

    <?php
    $cssfooter= "footer_1.css";
    include 'footer_1.php';
    ?>
