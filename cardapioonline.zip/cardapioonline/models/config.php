<?php
	//Configurações do banco de dados.
	define('DB_HOST','localhost');
	define('DB_NAME','cardapioonline');
	define('DB_USER','root');
	define('DB_PASS','usbw');
?>