<?php
//CLASSE
    class Endereço{
        private $idEndereço;
        private $cep;
        private $numeroCasa;
        private $complemento;

//CONSTRUTOR
    public function __construct($idEndereço, $cep, $numeroCasa, $complemento){
        $this->idEndereço = $idEndereço;
        $this->cep = $cep;
        $this->numeroCasa = $numeroCasa;
        $this->complemento = $complemento;
    }

//SETTERS E GETTERS
    public function setIdEndereço($idEndereço){
        $this->idEndereço = $idEndereço;
    }
    public function getIdEndereço(){
        return $this->idEndereço;
    }

    public function setCep($cep){
        $this->cep = $cep;
    }
    public function getCep(){
        return $this->cep;
    }

    public function setNumeroCasa($numeroCasa){
        $this->numeroCasa = $numeroCasa;
    }
    public function getNumeroCasa(){
        return $this->numeroCasa;
    }

    public function setComplemento($complemento){
        $this->complemento = $complemento;
    }
    public function getComplemento(){
        return $this->complemento;
    }
    }
?>