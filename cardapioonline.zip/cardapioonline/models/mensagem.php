<?php
//Se a sessão não existir, então inicia a sessão
if (session_status() === PHP_SESSION_NONE) {
	session_start();
}

//se a variável de sessão mensagem possuir existir, então deve mostrar a mensagem na tela.
if(isset($_SESSION['mensagem'])): 
?>
	
 <script>
   //Mensagem de alerta javascript do materialize
	window.onload = function(){
		  M.toast({html: '<?php echo $_SESSION['mensagem']; ?>', classes: 'config_toast'});
		
		
	};
</script>

<style>
	.config_toast{
		background-color: #ADB895;
		color: #FEEBEB;
		border: black solid 0.1rem;
		border-radius: 1rem;
		box-shadow: 1rem 1rem 0.4rem #000000;
		font-size: 2rem;
		padding: 1.5rem;
	}
</style>



<?php 	
endif;
session_unset(); //limpar a sessão
?>