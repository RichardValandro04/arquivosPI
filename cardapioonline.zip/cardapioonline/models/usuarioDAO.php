<?php

require_once 'crud.php';
require_once 'cliente.php';



class UsuarioDAO extends CRUD{

    protected $table = 'usuarios';

    public function insert($usuario){
        $sql = "INSERT INTO $this->table (nome, email, cpf, telefone, senha) VALUES (:nome, :email, :cpf, :telefone, :senha)";


        $stmt = Database::prepare($sql);
		$stmt->bindParam(':nome', $usuario->getNome());
		$stmt->bindParam(':email', $usuario->getEmail());
		$stmt->bindParam(':cpf', $usuario->getCpf());
		$stmt->bindParam(':telefone', $usuario->getTelefone());
		$stmt->bindParam(':senha', $usuario->getSenha());
		
		return $stmt->execute();
    }

    public function update($idUsuario, $cliente){

        $sql = "UPDATE $this->table SET nome = :nome , email = :email, cpf = :cpf, telefone = :telefone, senha = :telefone WHERE id = :id";


        $stmt = Database::prepare($sql);
		$stmt->bindParam(':nome', $usuario->getNome());
		$stmt->bindParam(':email', $usuario->getEmail());
		$stmt->bindParam(':cpf', $usuario->getCpf());
		$stmt->bindParam(':telefone', $usuario->getTelefone());
		$stmt->bindParam(':senha', $usuario->getSenha());
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
		
		return $stmt->execute();
    }
}
?>