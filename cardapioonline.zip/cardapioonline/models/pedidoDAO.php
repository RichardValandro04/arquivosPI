<?php

require_once 'crud.php';
require_once 'pedido.php';



class pedidoDAO extends CRUD{
//pk_id_pedido	data_entrega	hora_entrega	valortotal_pedido	fk_id_usuario	fk_id_endereco	metodo_entrega	situacao	

    protected $table = 'pedidos';

    public function insert($pedido){
        $sql = "INSERT INTO $this->table 
        (data_entrega,
        hora_entrega,
        valortotal_pedido,
        fk_id_usuario,
        fk_id_endereco,
        metodo_entrega,
        situacao) 

    VALUES (:data_entrega,
        :hora_entrega,
        :valortotal_pedido,
        :fk_id_usuario,
        :fk_id_endereco,
        :metodo_entrega,
        :situacao)";
        
        $data_entrega = $pedido->getDataEntrega();
        $hora_entrega = $pedido->getHoraEntrega();
        $valortotal_pedido = $pedido->getValorTotalPedido();
        $fk_id_usuario = $pedido->getIdUsuario();
        $fk_id_endereco = $pedido->getIdEndereco();
        $metodo_entrega = $pedido->getMetodoDeEntrega();
        $situacao = $pedido->getSituacao();

        $stmt = Database::prepare($sql);
		$stmt->bindParam(':data_entrega', $data_entrega);
		$stmt->bindParam(':hora_entrega', $hora_entrega);
		$stmt->bindParam(':valortotal_pedido', $valortotal_pedido);
        $stmt->bindParam(':fk_id_usuario', $fk_id_usuario);
        $stmt->bindParam(':fk_id_endereco', $fk_id_endereco);
        $stmt->bindParam(':metodo_entrega', $metodo_entrega);
        $stmt->bindParam(':situacao', $situacao);
		
		return $stmt->execute();
    }

    public function update($idPedido, $pedido) {
        // Consulta SQL para atualizar um pedido
        $sql = "UPDATE $this->table 
                SET data_entrega = :data_entrega, 
                    hora_entrega = :hora_entrega, 
                    valortotal_pedido = :valortotal_pedido, 
                    fk_id_usuario = :fk_id_usuario, 
                    fk_id_endereco = :fk_id_endereco, 
                    metodo_entrega = :metodo_entrega, 
                    situacao = :situacao 
                WHERE pk_id_pedido = :pk_id_pedido";
        
        // Preparar valores
        $pk_id_pedido = $pedido->getIdPedido();
        $data_entrega = $pedido->getDataEntrega();
        $hora_entrega = $pedido->getHoraEntrega();
        $valortotal_pedido = $pedido->getValorTotalPedido();
        $fk_id_usuario = $pedido->getIdUsuario();
        $fk_id_endereco = $pedido->getIdEndereco();
        $metodo_entrega = $pedido->getMetodoDeEntrega();
        $situacao = $pedido->getSituacao();


        $stmt = Database::prepare($sql);
        $stmt->bindParam(':pk_id_pedido', $pk_id_pedido, PDO::PARAM_INT);
        $stmt->bindParam(':data_entrega', $data_entrega);
        $stmt->bindParam(':hora_entrega', $hora_entrega);
        $stmt->bindParam(':valortotal_pedido', $valortotal_pedido);
        $stmt->bindParam(':fk_id_usuario', $fk_id_usuario, PDO::PARAM_INT);
        $stmt->bindParam(':fk_id_endereco', $fk_id_endereco, PDO::PARAM_INT);
        $stmt->bindParam(':metodo_entrega', $metodo_entrega);
        $stmt->bindParam(':situacao', $situacao);
            
        return $stmt->execute();
    }

    public function pesquisaPedidosPorSituacao($situacao){
        $sql = "SELECT * FROM $this->table WHERE situacao = :situacao";
        $stmt = Database::prepare($sql);
        $stmt->bindParam(':situacao', $situacao);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);

    }

    public function pesquisaPedidosPorUsuario($situacao, $idUsuario){
        $sql = "SELECT * FROM $this->table WHERE situacao = :situacao AND fk_id_usuario = :fk_id_usuario";
        $stmt = Database::prepare($sql);
        $stmt->bindParam(':situacao', $situacao);
        $stmt->bindParam(':fk_id_usuario', $idUsuario, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);

    }
}
?>