    <?php 
        $cssfooter;
        echo "<link rel='stylesheet' href='css/" . $cssfooter .  "'>"
    
    ?>

    <!--FOOTER-->
    <!-- Footer inclui o botão de voltar -->
    <footer>
        <div class="voltar">
            <div class="icone_voltar">
                <img src="imagens/icone_voltar.png" alt="icone_voltar">
            </div>
        </div>
    </footer>

</body>
</html>