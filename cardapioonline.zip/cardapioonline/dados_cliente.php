    <?php
    session_start();
    $nome = $_SESSION['nome'];
    $email = $_SESSION['email'];
    $cpf = $_SESSION['cpf'];
    $telefone = $_SESSION['telefone'];

    $csscustomiza = "dados_cliente.css";
    include 'header_3.php';
    require_once 'controllers/controllerLogin.php';

    ?>

    

    <div class="identificador_pagina">
        <img src="imagens/icone_pessoa.png" alt="" id="icone_pessoa">
        <h1>MEUS DADOS</h1>
    </div>

    <!--SECTION-->
    <article>
        <section class="dados">
            <!--NOME-->
            <div class="campo_nome">
                <label for="nome">Nome Completo</label>
                <input type="text" name="nome" value="<?php echo htmlspecialchars($nome); ?>" disabled>
            </div>

            <form>
                <!--EMAIL-->
                <div class="linha_email">
                    <div class="campo_email">
                        <label for="email">Email</label>
                        <input type="email" class="input_email" name="email" value="<?php echo htmlspecialchars($email); ?>" disabled>
                    </div>
                    
                    <div class="icone_editar">
                        <img src="imagens/icone_editar.png" alt="icone_editar" class="alt_email">
                        <button type="submit" class="confirmar_email" style="display: none; background: none; border: none;">
                            <img src="imagens/checkmark.png" alt="confirmar_editar">
                        </button>
                    </div>
                </div>
            </form>
            
            <form>
                <div class="linha_telefone">
                    <div class="campo_cpf">
                        <label for="cpf">CPF</label>
                        <input type="text" class="input_cpf" name="CPF" value="<?php echo htmlspecialchars($cpf); ?>" disabled>
                    </div>

                    <div class="campo_telefone">
                        <label for="telefone">Telefone</label>
                        <input type="tel" class="input_telefone" name="telefone" id="telefone" value="<?php echo htmlspecialchars($telefone); ?>" disabled>
                    </div>
                
                    <div class="icone_editar">
                        <img src="imagens/icone_editar.png" alt="icone_editar" class="alt_telefone">
                        <button type="submit" class="confirmar_telefone" style="display: none; background: none; border: none;">
                            <img src="imagens/checkmark.png" alt="confirmar_editar">
                        </button>
                    </div>    
                </div>
            </form>
            
        </section>
    </article>



    <?php
    $cssfooter= "footer_2.css";
    include 'footer_2.php';
    ?>
