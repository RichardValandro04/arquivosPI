    <?php
    $csscustomiza = "pedidos_cliente.css";
    include 'header_3.php';

    ?>

    <div class="identificador_pagina">
        <img src="imagens/icone_pedidos.png" alt="" id="icone_pessoa">
        <h1>MEUS PEDIDOS</h1>
    </div>

    <article>
        <section class = "dados">
            <div class="column">
                <div class="col s40">
                    <ul class="tabs tabs-fixed-width">
                        <li class="tab col s10"><a href="#aguardandoConfirmacao">Aguardando Confirmação</a></li>
                        <li class="tab col s10"><a href="#emAndamento">Em Andamento</a></li>
                        <li class="tab col s10"><a href="#concluidos">Concluídos</a></li>
                        <li class="tab col s10"><a href="#cancelados">Cancelados</a></li>
                    </ul>
                </div>

                <div id="aguardandoConfirmacao" class="col s40 red">
                    <div class = "pedido">
                            <h2 class="num_pedido">#0003</h2>
                            <h2 class="date">22/03/2024</h2>
                            <h2 class="valor">R$ 19,90</h2>
                    </div>
                </div>


                <div id="emAndamento" class="col s40 blue">
                    <div class = "pedido">
                        <h2 class="num_pedido">#0003</h2>
                        <h2 class="date">22/03/2024</h2>
                        <h2 class="valor">R$ 19,90</h2>
                    </div>
                </div>

                <div id="concluidos" class="col s40 pink">
                    <div class = "pedido">
                            <h2 class="num_pedido">#0003</h2>
                            <h2 class="date">22/03/2024</h2>
                            <h2 class="valor">R$ 19,90</h2>
                        </div>
                </div>

                <div id="cancelados" class="col s40 yellow">
                    <div class = "pedido">
                            <h2 class="num_pedido">#0003</h2>
                            <h2 class="date">22/03/2024</h2>
                            <h2 class="valor">R$ 19,90</h2>
                        </div>
                </div>

            </div>
        </section>
    </article>



    <?php
    $cssfooter= "footer_2.css";
    include 'footer_2.php';

    ?>
    
