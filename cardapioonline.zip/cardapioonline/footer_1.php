    <?php 
        $cssfooter;
        echo "<link rel='stylesheet' href='css/" . $cssfooter .  "'>"
    
    ?>

    <!-- footer inclui uma div com uma flor tulipa alinhada ao canto inferior esquerdo e uma div com o botão de voltar -->
    <footer>
        <div>
            <img src="imagens/tulipas_footer.png" alt="tulipas" class="tulipasbaixo">
        </div>

        <div class="voltar">
            <div class="icone_voltar">
                <img src="imagens/icone_voltar.png" alt="icone_voltar">
            </div>
        </div>
    </footer>

    
</body>
</html>