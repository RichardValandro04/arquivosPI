
    <?php
    $csscustomiza = "nova_senha.css";
    include 'header_2.php';

    ?>

    <!--nav "container" que inclui uma div "nova-senha", a div "confirmar-senha" e o botão de confirmação de alteração de senha-->
    <form class="container" action = "controllers/controllerNovaSenha.php" method = "POST">
        <!--div que inclui um label, um input e uma tag "p"-->
        <div class="nova_senha">
            <label for="novasenha">Nova Senha</label>
            <input type="password" id="novasenha" name="novasenha">
        </div>

        <!--div que inclui um label e um input-->
        <div class="confirmar_senha">
            <label for="confsenha">Confirmar Nova Senha</label>
            <input type="password" id="confsenha" name="confsenha">
        </div>
        <!--botao que realiza a alteração de senha-->
        <button type="submit" class="botao_alterar" name="botao_alterar" value="alterar">ALTERAR</button>
    </form>

    <?php
    $cssfooter= "footer_1.css";
    include 'footer_1.php';
    ?>
