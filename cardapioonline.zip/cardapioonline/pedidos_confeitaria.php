
    <?php

    if(session_status() === PHP_SESSION_NONE){
        session_start();
    }
        
        $csscustomiza= "pedidos_confeitaria.css";
        require_once 'header_1.php';
        include 'controllers/controllerPedidosConfeitaria.php';
        

    ?>

    <!-- Article que agrupa todos os componentes da página, com exceção do header -->
    <article>

        <!-- Section meus-clientes inclui um ícone de pessoas e o texto clientes, identificando a página  -->
        <section class="identificador_pagina">
            <img src="imagens/icone_pedidos.png" alt="clientes_icon">
            <p>PEDIDOS</p>
        </section>


        <section class="dados">
            <div class="column">
                <div class="col s40">
                    <ul class="tabs tabs-fixed-width">
                        <li class="tab col s8"><a href="#aguardandoConfirmacao">Aguardando Confirmação</a></li>
                        <li class="tab col s8"><a href="#pagamentoPendente">Pagamento Pendente</a></li>
                        <li class="tab col s8"><a href="#emAndamento">Em Andamento</a></li>
                        <li class="tab col s8"><a href="#concluidos">Concluídos</a></li>
                        <li class="tab col s8"><a href="#cancelados">Cancelados</a></li>
                    </ul>
                </div>

                <!-- Aguardando Confirmação -->
                <div id="aguardandoConfirmacao" class="col s40 blue">
                    <div class = "titulos">
                        <h4>ID PEDIDO</h4>
                        <h4>DATA ENTREGA</h4>
                        <h4>VALOR TOTAL</h4>
                    </div>
                    <div class="pedidos">
                        <?php
                            $situacao = 'aguardando';
                            $controllerPedidosConfeitaria = new ControllerPedidosConfeitaria();
                            $aguardandoConfirmacao = $controllerPedidosConfeitaria->listaPedidos($situacao);

                            $num = count($aguardandoConfirmacao);

                            if($num > 0) {
                                foreach ($aguardandoConfirmacao as $linha) {
                                    ?>
                                        <div class="pedido">
                                            <h3 class="num_pedido"><?php echo htmlspecialchars($linha['pk_id_pedido']); ?></h3>
                                            <h3 class="date"><?php echo htmlspecialchars($linha['data_entrega']); ?></h3>
                                            <h3 class="valor">R$ <?php echo htmlspecialchars($linha['valortotal_pedido']); ?>,00</h3>
                                        </div>
                            <?php
                                }
                            } else{
                                ?>
                                <div class = "divNenhum">
                                    <h1>NENHUM PEDIDO ENCONTRADO</h1>
                                </div>
                                
                            <?php
                            }
                            ?>
                    </div>    
                </div>

                <!-- Pagamento Pendente -->
                <div id="pagamentoPendente" class="col s40 yellow">
                    <div class = "titulos">
                        <h4>ID PEDIDO</h4>
                        <h4>DATA ENTREGA</h4>
                        <h4>VALOR TOTAL</h4>
                    </div>
                    <div class="pedidos">
                        <?php
                            $situacao = 'pagamento pendente';
                            $controllerPedidosConfeitaria = new ControllerPedidosConfeitaria();
                            $pagamentoPendente = $controllerPedidosConfeitaria->listaPedidos($situacao);

                            $num = count($pagamentoPendente);

                            if($num > 0) {
                                foreach ($pagamentoPendente as $linha) {
                                    ?>
                                        <div class="pedido">
                                            <h3 class="num_pedido"><?php echo htmlspecialchars($linha['pk_id_pedido']); ?></h3>
                                            <h3 class="date"><?php echo htmlspecialchars($linha['data_entrega']); ?></h3>
                                            <h3 class="valor">R$ <?php echo htmlspecialchars($linha['valortotal_pedido']); ?>,00</h3>
                                        </div>
                            <?php
                                }
                            } else{
                                ?>
                                <div class = "divNenhum">
                                    <h1>NENHUM PEDIDO ENCONTRADO</h1>
                                </div>
                                
                            <?php
                            }
                            ?>
                    </div>    
                </div> 
                
                <!-- Em Andamento -->
                <div id="emAndamento" class="col s40 pink">
                    <div class = "titulos">
                        <h4>ID PEDIDO</h4>
                        <h4>DATA ENTREGA</h4>
                        <h4>VALOR TOTAL</h4>
                    </div>
                    <div class="pedidos">
                        <?php
                            $situacao = 'em andamento';
                            $controllerPedidosConfeitaria = new ControllerPedidosConfeitaria();
                            $emAndamento = $controllerPedidosConfeitaria->listaPedidos($situacao);

                            $num = count($emAndamento);

                            if($num > 0) {
                                foreach ($emAndamento as $linha) {
                                    ?>
                                        <div class="pedido">
                                            <h3 class="num_pedido"><?php echo htmlspecialchars($linha['pk_id_pedido']); ?></h3>
                                            <h3 class="date"><?php echo htmlspecialchars($linha['data_entrega']); ?></h3>
                                            <h3 class="valor">R$ <?php echo htmlspecialchars($linha['valortotal_pedido']); ?>,00</h3>
                                        </div>
                            <?php
                                }
                            } else{
                                ?>
                                <div class = "divNenhum">
                                    <h1>NENHUM PEDIDO ENCONTRADO</h1>
                                </div>
                                
                            <?php
                            }
                            ?>
                    </div>    
                </div> 
                
                <!-- Concluidos -->
                <div id="concluidos" class="col s40 green">
                    <div class = "titulos">
                        <h4>ID PEDIDO</h4>
                        <h4>DATA ENTREGA</h4>
                        <h4>VALOR TOTAL</h4>
                    </div>
                    <div class="pedidos">
                        <?php
                            $situacao = 'concluido';
                            $controllerPedidosConfeitaria = new ControllerPedidosConfeitaria();
                            $concluido = $controllerPedidosConfeitaria->listaPedidos($situacao);

                            $num = count($concluido);

                            if($num > 0) {
                                foreach ($concluido as $linha) {
                                    ?>
                                        <div class="pedido">
                                            <h3 class="num_pedido"><?php echo htmlspecialchars($linha['pk_id_pedido']); ?></h3>
                                            <h3 class="date"><?php echo htmlspecialchars($linha['data_entrega']); ?></h3>
                                            <h3 class="valor">R$ <?php echo htmlspecialchars($linha['valortotal_pedido']); ?>,00</h3>
                                        </div>
                            <?php
                                }
                            } else{
                                ?>
                                <div class = "divNenhum">
                                    <h1>NENHUM PEDIDO ENCONTRADO</h1>
                                </div>
                                
                            <?php
                            }
                            ?>
                    </div>    
                </div>   
                
                <!-- Cancelados -->
                <div id="cancelados" class="col s40 red">
                    <div class = "titulos">
                        <h4>ID PEDIDO</h4>
                        <h4>DATA ENTREGA</h4>
                        <h4>VALOR TOTAL</h4>
                    </div>
                    <div class="pedidos">
                        <?php
                            $situacao = 'cancelado';
                            $controllerPedidosConfeitaria = new ControllerPedidosConfeitaria();
                            $cancelado = $controllerPedidosConfeitaria->listaPedidos($situacao);

                            $num = count($cancelado);

                            if($num > 0) {
                                foreach ($cancelado as $linha) {
                                    ?>
                                        <div class="pedido">
                                            <h3 class="num_pedido"><?php echo htmlspecialchars($linha['pk_id_pedido']); ?></h3>
                                            <h3 class="date"><?php echo htmlspecialchars($linha['data_entrega']); ?></h3>
                                            <h3 class="valor">R$ <?php echo htmlspecialchars($linha['valortotal_pedido']); ?>,00</h3>
                                        </div>
                            <?php
                                }
                            } else{
                                ?>
                                <div class = "divNenhum">
                                    <h1>NENHUM PEDIDO ENCONTRADO</h1>
                                </div>
                                
                            <?php
                            }
                            ?>
                    </div>    
                </div> 
            </div>
        </section>                     
    </article>

    <?php

    $cssfooter= "footer_2.css";
    include 'footer_2.php';

    ?>
