    <?php

    
    if(session_status() === PHP_SESSION_NONE){
        session_start();
    }
    require_once 'controllers/controllerCardapioConfeitaria.php';
    
    $csscustomiza = "cardapio_confeitaria.css";
    include 'header_1.php';

        
    ?>

    <!--ARTICLE - 2 SECTIONS-->
    <article>

        <!-- Section meus-clientes inclui um ícone de pessoas e o texto clientes, identificando a página  -->

        <!-- SECTION CONTENDO CARDÁPIO E ADICIONAR ITENS-->
        <section>
            <div class="identificador_pagina">
                <img src="imagens/icone_cardapio.png" alt="clientes_icon">
                <p>CARDÁPIO</p>
            </div>
            <!-- ADD RECHEIO - ADD DOCE-->
            <div class="flexcoluns">
                <!-- DIV ADD RECHEIO E ADD DOCE-->
                <div class="add-recheio-doce">
                    <!--ADD RECHEIO-->
                    <div class="adicionar_recheio">
                        <img id="icon_add" src="imagens/icone_add.png" alt="">
                        <p class = "adicionar">ADICIONAR NOVO<span>RECHEIO</span></p>
                    </div>
                    <!--ADD DOCE-->
                    <div class="adicionar_doce">
                        <img id="icon_add" src="imagens/icone_add.png" alt="">
                        <p class = "adicionar">ADICIONAR NOVO<span>DOCE</span></p>
                    </div>
                </div>
            </div>
        </section>

        <section class = "tabelasRecheios">
            <div class="column tabela">
                <div class="col s6">
                    <ul class="tabs tabs-fixed-width">
                        <li class="tab col s3"><a href="#doces">DOCES</a></li>
                        <li class="tab col s3"><a href="#recheios">RECHEIOS</a></li>
                    </ul>
                </div>

                <div id="doces" class="col">
                    <?php
                    $controllerCardapioConfeitaria = new ControllerCardapioConfeitaria();
                    $doces = $controllerCardapioConfeitaria->listarDoces();


                    foreach ($doces as $linha) {
                    ?>
                    <div class="doce">
                        <h3 class="nome_sabor"><?php echo htmlspecialchars($linha['nome_sabor']); ?></h3>
                        <h3 class="valor_dezena">R$ <?php echo htmlspecialchars($linha['valor_dezena']);?>,00</h3>
                        <img src="imagens/icone_excluir.png" alt="excluir" class = "icone_excluir">
                    </div>
                    <?php
                    }
                    ?>
                </div>

                <div id="recheios" class="col">
                <?php
                $recheios = $controllerCardapioConfeitaria->listarRecheios();
                
                foreach ($recheios as $linha) {
                    ?>
                    <div class="recheio">
                        <h3 class="nome_recheio"><?php echo htmlspecialchars($linha['nome_recheio']); ?></h3>
                        <img src="imagens/icone_excluir.png" alt="excluir" class = "icone_excluir">
                    </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </section>
        
        <section></section>

        <dialog class = "dialogNovoDoce">
            <!-- header que inclui h1 com identificação da tela -->
            <header class = "headerModal">
                <div class = "nomePagina">
                    <p>ADICIONAR NOVO DOCE</p>
                </div>

                <div class = "btn_fechar">
                    <img class = "fecharDoce botaoFechar" src="imagens/fechar.png" alt="fechar">
                </div>
                
            </header>
            <form class="container">

                <!--div que inclui dois campos, um label e um input-->
                <div class="campos">
                <label for="nome_recheio">NOME</label>
                <input type="text" name="nome_recheio" id="nome_recheio">
                </div>

                <button type="submit" class="btn_salvar">SALVAR</button>

            </form>
        </dialog>
        
        <dialog class = "dialogNovoRecheio">
            <!-- header que inclui h1 com identificação da tela -->
            <header class = "headerModal">
            <div></div>
            <div class = "nomePagina">
                <p>ADICIONAR NOVO RECHEIO</p>
            </div>

            <div class = "btn_fechar">
                <img class = "fecharRecheio botaoFechar" src="imagens/fechar.png" alt="fechar">
            </div>
                
            </header>
            <form class="container">

                <div class="campo_nome">
                <label for="nome_recheio" class="label_campos">NOME</label>
                <input type="text" name="nome_recheio" id="nome_recheio" class="campos">
                </div>

                <div class="campo_desc">
                <label for="desc_doce" class="label_campos">DESCRIÇÃO</label>
                <input type="text" name="desc_doce" id="desc_doce" class="campos">
                </div>

                <div class="campo_valor">
                <label for="valor_doce" class="label_campos">VALOR DEZENA</label>
                <input type="text" name="valor_doce" id="valor_doce" class="campos">
                <!-- ATENCAO, MUDAR TYPE PARA RECEBER VALOR EM REAL-->
                </div>

                <div class="campo_foto">
                <label for="foto_doce" class="label_campos">FOTO</label>
                <input type="file" name="foto_doce" id="foto_doce" class="campos">
                </div>

                <!-- botao de enviar o formulario -->
                <button type="submit" class="btn_salvar">SALVAR</button>

            </form>
        </dialog>



    </article>

    <?php
    $cssfooter= "footer_2.css";
    require_once 'footer_2.php';
    ?>

