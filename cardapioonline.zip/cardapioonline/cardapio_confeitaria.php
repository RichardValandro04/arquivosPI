    <?php

    
    if(session_status() === PHP_SESSION_NONE){
        session_start();
    }
    require_once 'controllers/controllerCardapioConfeitaria.php';
    
    $csscustomiza = "cardapio_confeitaria.css";
    include 'header_1.php';

        
    ?>

    <!--ARTICLE - 2 SECTIONS-->
    <article>

        <!-- Section meus-clientes inclui um ícone de pessoas e o texto clientes, identificando a página  -->

        <!-- SECTION CONTENDO CARDÁPIO E ADICIONAR ITENS-->
        <section>
            <div class="identificador_pagina">
                <img src="imagens/icone_cardapio.png" alt="clientes_icon">
                <p>CARDÁPIO</p>
            </div>
            <!-- ADD RECHEIO - ADD DOCE-->
            <div class="flexcoluns">
                <!-- DIV ADD RECHEIO E ADD DOCE-->
                <div class="add-recheio-doce">
                    <!--ADD RECHEIO-->
                    <div class="adicionar_recheio">
                        <img id="icon_add" src="imagens/icone_add.png" alt="">
                        <p class = "adicionar">ADICIONAR NOVO<span>RECHEIO</span></p>
                    </div>
                    <!--ADD DOCE-->
                    <div class="adicionar_doce">
                        <img id="icon_add" src="imagens/icone_add.png" alt="">
                        <p class = "adicionar">ADICIONAR NOVO<span>DOCE</span></p>
                    </div>
                </div>
            </div>
        </section>

        <section class = "tabelasRecheios">
            <div class="column tabela">
                <div class="col s6">
                    <ul class="tabs tabs-fixed-width">
                        <li class="tab col s3"><a href="#doces">DOCES</a></li>
                        <li class="tab col s3"><a href="#recheios">RECHEIOS</a></li>
                    </ul>
                </div>

                <div id="doces" class="col">
                    <?php
                    $controllerCardapioConfeitaria = new ControllerCardapioConfeitaria();
                    $doces = $controllerCardapioConfeitaria->listarDoces();


                    foreach ($doces as $linha) {
                    ?>
                    <div class="doce">
                        <h3 class="nome_sabor"><?php echo htmlspecialchars($linha['nome_sabor']); ?></h3>
                        <h3 class="valor_dezena">R$ <?php echo htmlspecialchars($linha['valor_dezena']);?>,00</h3>
                        <img src="imagens/icone_excluir.png" alt="excluir" class = "icone_excluir">
                    </div>
                    <?php
                    }
                    ?>
                </div>

                <div id="recheios" class="col">
                <?php
                $recheios = $controllerCardapioConfeitaria->listarRecheios();
                
                foreach ($recheios as $linha) {
                    ?>
                    <div class="recheio">
                        <h3 class="nome_recheio"><?php echo htmlspecialchars($linha['nome_recheio']); ?></h3>
                        <img src="imagens/icone_excluir.png" alt="excluir" class = "icone_excluir">
                    </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
        </section>
        
        <section></section>


    </article>

    <?php
    $cssfooter= "footer_2.css";
    require_once 'footer_2.php';
    ?>

