const select = document.querySelector("#lista");
const enderecoForm = document.querySelector(".form_endereco");

// Captura os botões de rádio
var btn_entrega = document.querySelector(".rd_entrega");
var btn_retirada = document.querySelector(".rd_retirada");

// Captura a dropdown list e define seu display como none
var divLista = document.querySelector(".selecao_endereco");
divLista.classList.add("hide-dropdown");

// Função para atualizar o formulário de endereço com base na seleção
function atualizarFormulario() {
    if (select.value === 'novo') {
        enderecoForm.classList.add('exibirFormEndereco');
        enderecoForm.classList.remove('ocultarFormEndereco');
    } else {
        enderecoForm.classList.add('ocultarFormEndereco');
        enderecoForm.classList.remove('exibirFormEndereco');
    }
}

// Adiciona um evento de escuta ao select para acionar a função quando o valor muda
select.addEventListener('change', atualizarFormulario);

// Adiciona um evento de escuta aos botões de rádio
btn_entrega.addEventListener("change", () => {
    if (btn_entrega.checked) {
        // Se o botão de rádio de entrega estiver selecionado, exibe a dropdown
        divLista.classList.remove("hide-dropdown");
        divLista.classList.add("show-dropdown");
        atualizarFormulario(); // Atualiza o formulário quando a dropdown é exibida
    } else {
        // Caso contrário, esconde a dropdown
        divLista.classList.remove("show-dropdown");
        divLista.classList.add("hide-dropdown");
    }
});

// Adiciona um evento de escuta ao botão de rádio de retirada se necessário
btn_retirada.addEventListener("change", () => {
    if (btn_retirada.checked) {
        // Esconde a dropdown quando a opção de retirada é selecionada
        divLista.classList.remove("show-dropdown");
        divLista.classList.add("hide-dropdown");
    }
});


const botaoIr = document.querySelector(".botaoIr");
const inputDate = document.querySelector("#data_entrega");
const inputTime = document.querySelector("#hora_entrega");

botaoIr.addEventListener("click", () => {

    // Obtém os valores dos inputs
    const dateValue = inputDate.value;
    const timeValue = inputTime.value;
    
    // Verifica se os inputs têm valores selecionados
    if (!dateValue || !timeValue) {
        alert("Por favor, selecione a data e a hora.");
        return;
    }
    
    if(!btn_retirada.checked && !btn_entrega.checked){
        alert("Selecione Entrega ou Retirada");
        return;
    }


});



