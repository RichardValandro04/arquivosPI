//capturando botao de alterar senha
const botao_alterar = document.querySelector(".botao_alterar");


//adicionando evento de click para exibir um alert de senha alterada
// obs.: a lógica para validação de senha ainda deverá ser aplicada
botao_alterar.addEventListener("click", () => {
    const senha = document.querySelector("#novasenha").value;
    const confSenha = document.querySelector("#confsenha").value;
    if(senha === null || confSenha === null){
        alert("Preencha todos os campos para continuar");
    }


});