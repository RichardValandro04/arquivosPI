
//esse trem aqui é para selecionar as imagens para realizar a troca, isso é ate a função de alterar dados
document.addEventListener('DOMContentLoaded', (event) => {
    document.querySelectorAll('.alt_email').forEach(img => {
        img.addEventListener('click', (event) => {
            console.log('Alterar Email clicado');
            alterarDados(event.target, 'email');
        });
    });
    document.querySelectorAll('.confirmar_email').forEach(img => {
        img.addEventListener('click', (event) => {
            console.log('Confirmar Email clicado');
            salvarDados(event.target, 'email');
        });
    });
    document.querySelectorAll('.alt_telefone').forEach(img => {
        img.addEventListener('click', (event) => {
            console.log('Alterar Telefone clicado');
            alterarDados(event.target, 'telefone');
        });
    });
    document.querySelectorAll('.confirmar_telefone').forEach(img => {
        img.addEventListener('click', (event) => {
            console.log('Confirmar Telefone clicado');
            salvarDados(event.target, 'telefone');
        });
    });
});

function alterarDados(img, campo) {
    const container = img.closest('.linha_' + campo);
    if (container) {
        console.log('Container encontrado para ' + campo);
        const input = container.querySelector('.input_' + campo);
        const confirmarImg = container.querySelector('.confirmar_' + campo);

        if (input && confirmarImg) {
            input.disabled = false;
            img.style.display = 'none';
            confirmarImg.style.display = 'inline';
        } 
    } 
    
}

function salvarDados(img, campo) {
    const container = img.closest('.linha_' + campo);
    if (container) {
        console.log('Container encontrado para ' + campo);
        const input = container.querySelector('.input_' + campo);
        const alterarImg = container.querySelector('.alt_' + campo);

        if (input && alterarImg) {
            console.log('Campo ' + campo + ' salvo');
            input.disabled = true;
            img.style.display = 'none';
            alterarImg.style.display = 'inline';
        } 
    } 
}

document.getElementById('telefone').addEventListener('input', function(e) {
    let valor = e.target.value.replace(/\D/g, ''); // Remove todos os caracteres não numéricos

    // Formatação
    if (valor.length <= 11) {
        valor = valor.replace(/(\d{2})(\d{0,5})(\d{0,4})/, '($1) $2-$3');
    } else {
        valor = valor.replace(/(\d{2})(\d{5})(\d{4}).*/, '($1) $2-$3');
    }

    e.target.value = valor;

    // Ajusta a posição do cursor após a formatação
    let cursorPos = e.target.selectionStart;
    setTimeout(() => {
        e.target.selectionStart = e.target.selectionEnd = cursorPos;
    }, 0);
});


