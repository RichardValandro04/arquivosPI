const botaoEmail = document.querySelector(".alt_email");
const modalEmail = document.querySelector(".dialogEmail");
const fecharEmail = document.querySelector(".fecharEmail");

botaoEmail.onclick = function(){
    modalEmail.showModal()
}

fecharEmail.onclick = function(){
    modalEmail.close()
}

const botaoTelefone = document.querySelector(".alt_telefone");
const modalTelefone = document.querySelector(".dialogTelefone");
const fecharTelefone = document.querySelector(".fecharTelefone");

botaoTelefone.onclick = function(){
    modalTelefone.showModal()
}

fecharTelefone.onclick = function(){
    modalTelefone.close()
}

const botaoEndereco = document.querySelector(".btn_endereco");
const modalEndereco = document.querySelector(".dialogEndereco");
const fecharEndereco = document.querySelector(".fecharEndereco");

botaoEndereco.onclick = function(){
    modalEndereco.showModal()
}

fecharEndereco.onclick = function(){
    modalEndereco.close()
}




document.getElementById('telefone').addEventListener('input', function(e) {
    let valor = e.target.value.replace(/\D/g, ''); // Remove todos os caracteres não numéricos

    // Formatação
    if (valor.length <= 11) {
        valor = valor.replace(/(\d{2})(\d{0,5})(\d{0,4})/, '($1) $2-$3');
    } else {
        valor = valor.replace(/(\d{2})(\d{5})(\d{4}).*/, '($1) $2-$3');
    }

    e.target.value = valor;

    // Ajusta a posição do cursor após a formatação
    let cursorPos = e.target.selectionStart;
    setTimeout(() => {
        e.target.selectionStart = e.target.selectionEnd = cursorPos;
    }, 0);
});


