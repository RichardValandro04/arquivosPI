const botaoEmail = document.querySelector(".alt_email");
const modalEmail = document.querySelector(".dialogEmail");
const fecharEmail = document.querySelector(".fecharEmail");

botaoEmail.onclick = function(){
    modalEmail.showModal()

    document.querySelector("#formEmail").onsubmit = function(event) {
        var email = document.querySelector("#campo_email").value.trim();

        // Verifica se o email está vazio ou contém apenas espaços
        if (!email) {
            alert("Preencha o campo de e-mail!");
            return false; // Impede o envio do formulário
        }
    }
}

fecharEmail.onclick = function(){
    modalEmail.close();
}

const botaoTelefone = document.querySelector(".alt_telefone");
const modalTelefone = document.querySelector(".dialogTelefone");
const fecharTelefone = document.querySelector(".fecharTelefone");

botaoTelefone.onclick = function(){
    modalTelefone.showModal()

    document.querySelector("#formTelefone").onsubmit = function(event) {
        var telefone = document.querySelector("#campo_telefone").value.trim();

        // Verifica se o telefone está vazio ou contém apenas espaços
        if (!telefone) {
            alert("Preencha o campo de telefone!");
            return false; // Impede o envio do formulário
        }
    }

    document.getElementById('campo_telefone').addEventListener('input', function(e) {
        let valor = e.target.value.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
    
        // Formatação
        if (valor.length <= 11) {
            valor = valor.replace(/(\d{2})(\d{0,5})(\d{0,4})/, '($1) $2-$3');
        } else {
            valor = valor.replace(/(\d{2})(\d{5})(\d{4}).*/, '($1) $2-$3');
        }
    
        e.target.value = valor;
    
        // Ajusta a posição do cursor após a formatação
        let cursorPos = e.target.selectionStart;
        setTimeout(() => {
            e.target.selectionStart = e.target.selectionEnd = cursorPos;
        }, 0);
    });
}

fecharTelefone.onclick = function(){
    modalTelefone.close()
}

const botaoEndereco = document.querySelector(".btn_endereco");
const modalEndereco = document.querySelector(".dialogEndereco");
const fecharEndereco = document.querySelector(".fecharEndereco");

botaoEndereco.onclick = function(){
    modalEndereco.showModal()
}

fecharEndereco.onclick = function(){
    modalEndereco.close()
}







