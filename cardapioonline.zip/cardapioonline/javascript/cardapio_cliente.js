const botao_pedido = document.querySelector(".botao_pedido");

botao_pedido.addEventListener("click", () => {window.location.href = "novo_pedido.php"})

// ------------------------------------------------ //

// Capturando os botões de abrir e fechar o modal e o próprio modal
const abrirModal = document.getElementById("div_carrinho");
const modal = document.getElementById("dialog_carrinho");
const fecharModal = document.getElementById("fechar");

// Função que abre modal
abrirModal.onclick=function(){
    modal.show();
    
}

// Função que fecha modal
fecharModal.onclick=function(){
    modal.close();
    
}
// ------------------------------------------------ //

// Limite de checkboxes que podem ser marcados
const limite = 3;

// Capturando todos os checkboxes
const checkboxes = document.querySelectorAll('input[type="checkbox"]');

// Adicionando evento de escuta para cada checkbox
checkboxes.forEach(function(checkbox) {
  checkbox.addEventListener('change', function() {
    // Contando quantos checkboxes estão marcados
    const marcadas = document.querySelectorAll('input[type="checkbox"]:checked');
    // Se o número de checkboxes marcados for maior que o limite, desmarca o último checkbox marcado e emite alerta
    if (marcadas.length > limite) {
      this.checked = false;
      alert("Você pode escolher no máximo 3 recheios")
    }
  });
});

// ------------------------------------------------ //




// -------------------------------------------------- //

document.addEventListener('DOMContentLoaded', () => {
  // Seleciona todos os botões de adicionar ao carrinho
  const cartButtons = document.querySelectorAll('.carrinho_buy');
  console.log('Botões de adicionar ao carrinho encontrados:', cartButtons);

  // Adiciona um event listener para cada botão
  cartButtons.forEach(button => {
      button.addEventListener('click', () => {
          const productId = button.getAttribute('data-product-id');
          const productName = button.closest('tr').querySelector('.nome_doce').textContent.trim();
          const productPrice = button.closest('tr').querySelector('.valor_doce').textContent.trim();
          const productQuantity = button.closest('tr').querySelector('.quantidade_doce').textContent.trim();

          const product = {
              id: productId,
              name: productName,
              price: productPrice,
              quantity: productQuantity
          };

          addToCart(product);
      });
  });

  // Seleciona o botão para abrir o carrinho e o diálogo do carrinho
  const openCartButton = document.getElementById('div_carrinho');
  const cartDialog = document.getElementById('dialog_carrinho');
  const closeCartButton = document.getElementById('fechar');

  // Adiciona um event listener para abrir o carrinho
  openCartButton.addEventListener('click', () => {
      cartDialog.showModal();
      updateCartContent(); // Atualiza o conteúdo do carrinho ao abrir
  });

  // Adiciona um event listener para fechar o carrinho
  closeCartButton.addEventListener('click', () => {
      cartDialog.close();
  });

  // Função para adicionar produto ao carrinho
  function addToCart(product) {
      const cartContent = document.getElementById('conteudo_carrinho');

      const newCartItem = document.createElement('div');
      newCartItem.classList.add('item-carrinho');
      newCartItem.innerHTML = `
          <p>${product.name} - ${product.price}</p>
          <button class="remover" data-product-id="${product.id}">Remover</button>
      `;

      const removeButton = newCartItem.querySelector('.remover');
      removeButton.addEventListener('click', () => {
          newCartItem.remove();
      });

      cartContent.appendChild(newCartItem);
  }

  // Função para atualizar o conteúdo do carrinho
  function updateCartContent() {
      const cartItems = document.querySelectorAll('.item-carrinho');
      cartItems.forEach(item => {
          item.remove();
      });
      // Aqui você poderia adicionar lógica para recriar os itens do carrinho se necessário
  }
});
