

const botaoDoce = document.querySelector(".adicionar_doce");
const modalDoce = document.querySelector(".dialogNovoDoce");

const botaoRecheio = document.querySelector(".adicionar_recheio");
const modalRecheio = document.querySelector(".dialogNovoRecheio");

const fecharDoce = document.querySelector(".fecharDoce");
const fecharRecheio = document.querySelector(".fecharRecheio");



botaoDoce.onclick = function(){
    modalDoce.showModal()
}

fecharDoce.onclick = function(){
    modalDoce.close()
}



botaoRecheio.onclick = function(){
    modalRecheio.showModal()
}

fecharRecheio.onclick = function(){
    modalRecheio.close()
}


$(document).ready(function(){
    $('.tabs').tabs();
});